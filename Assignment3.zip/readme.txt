For playing the game just download the zipfile and unzip it then open it with Unity 2018 version, this may not work on unity 2019 version.
Control:
W forward
S backward
A left
D right
Q up
E down
C generate a bomb which will freeze the shark for several seconds
Mouse camera rotate