﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateOcto : MonoBehaviour
{

    [SerializeField] float spawnTime;
    public GameObject octoPrefab;
    // Start is called before the first frame update
    void Start()
    {
        spawnTime = 20f;
    }

    // Update is called once per frame
    void Update()
    {
        checkSpawnTime();
    }

    private void checkSpawnTime()
    {
        spawnTime -= Time.deltaTime;
        if (spawnTime <= 0)
        {
            SpawnShark();
            spawnTime = 20f;
        }
    }

    private void SpawnShark()
    {
        Vector3 position = new Vector3(UnityEngine.Random.Range(-8, 19), 10.3f, UnityEngine.Random.Range(6, 30));
        Instantiate(octoPrefab, position, Quaternion.identity);
    }
}
