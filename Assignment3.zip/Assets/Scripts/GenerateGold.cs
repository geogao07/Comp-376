﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateGold : MonoBehaviour
{
    public GameObject largeGold;
    public GameObject mediumGold;
    public GameObject smallGold;
    [SerializeField] float spawnTime;
    
    // Start is called before the first frame update
    void Start()
    {
        spawnTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        checkSpawnTime();
    }

    private void checkSpawnTime()
    {
        spawnTime -= Time.deltaTime;
        if (spawnTime <= 0 )
        {
            destroyExistingGold();
            spawnGold();
            spawnTime = 30f;
        }
        
    }

    private void destroyExistingGold()
    {
        GameObject[] gold = GameObject.FindGameObjectsWithTag("Gold");
        foreach (GameObject goldobj in gold)
            GameObject.Destroy(goldobj);
    }

    private void spawnGold()
    {
        Vector3 position1 = new Vector3(UnityEngine.Random.Range(-8, 19), 10.3f, UnityEngine.Random.Range(6, 30));
        Instantiate(largeGold, position1, Quaternion.identity);
        Vector3 position2 = new Vector3(UnityEngine.Random.Range(-8, 19), 10.3f, UnityEngine.Random.Range(6, 30));
        Instantiate(mediumGold, position2, Quaternion.identity);
        Vector3 position3 = new Vector3(UnityEngine.Random.Range(-8, 19), 10.3f, UnityEngine.Random.Range(6, 30));
        Instantiate(smallGold, position3, Quaternion.identity);
    }
}
