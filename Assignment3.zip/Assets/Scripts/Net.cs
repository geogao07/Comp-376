﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Net : MonoBehaviour
{
    
    Rigidbody rb;
    public float timer = 5f;

    
    // Start is called before the first frame update
    void Start()
    {
      //  rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        // rb.velocity = direction * speed * Time.deltaTime;
        
        checkTime();

    }

    private void checkTime()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            Destroy(gameObject);
        }
    }

    //void OnCollisionEnter(Collision collision)
    //{

    //    if (collision.collider.tag == "shark")
    //    {

    //        Destroy(gameObject);
    //    }

    //}
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "shark")
        {
            Destroy(gameObject);
        }
    }
}
