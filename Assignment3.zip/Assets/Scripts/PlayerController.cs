﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] float moveSpeed = 5f;
    [SerializeField] float swimSpeed = 3f;
    [SerializeField] float netSpeed = 10f;

    float speedWithoutLoad = 0;
    int goldOnHold = 0;
    public GameObject netPrefab;
    private Vector3 moveDirection;
    Rigidbody myRididBody;
    public CharacterController controller;

    // Start is called before the first frame update
    void Start()
    {
         myRididBody = GetComponent<Rigidbody>();
        controller = GetComponent<CharacterController>();
        speedWithoutLoad = moveSpeed;

    }

    // Update is called once per frame
    void Update()
    {
        
            ThrowNet();
             PlayerMove();
        checkPosition();
        
    }

    private void checkPosition()
    {
        if (transform.position.y < 21)
        {
            FindObjectOfType<GameSession>().removeFatigue();
        }
        else if (transform.position.y >= 21)
        {
            FindObjectOfType<GameSession>().recoverFatigue();
        }
    }

    private void ThrowNet()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            GameObject NetObj = Instantiate(netPrefab,transform.position,Quaternion.identity) as GameObject;
            Rigidbody instNet = NetObj.GetComponent<Rigidbody>();
            
        }
    }


    //private void OnCollisionEnter(Collision collision)
    //{
    //    if (collision.collider.tag == "shark" || collision.collider.tag == "Knife")
    //    {
    //        FindObjectOfType<GameSession>().ProcessPlayerDeath();
    //        GameObject oxygen = GameObject.Find("Oxygen1");
    //        if (oxygen)
    //        {
    //            Destroy(oxygen.gameObject);
    //        }
            
    //    }
    //}
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag== "shark" || other.tag == "Knife")
        {
            FindObjectOfType<GameSession>().ProcessPlayerDeath();
            GameObject oxygen = GameObject.Find("Oxygen1");
            if (oxygen)
            {
                Destroy(oxygen.gameObject);
            }

        }
        if (other.tag == "boat")
        {
            FindObjectOfType<GameSession>().AddToScore(goldOnHold);
            goldOnHold = 0;
        }
        if (other.tag == "Nitro")
        {
            increaseSpeed();
            GameObject nitro = GameObject.Find("SuperNitro");
            if (nitro)
            {
                Destroy(nitro.gameObject);
            }

        }

    }

    private void increaseSpeed()
    {
        moveSpeed *= 2;
        swimSpeed *= 2;
    }

    public void CarryGold(int gold)
    {
        goldOnHold = gold;

        if (goldOnHold == 1)
        {
            moveSpeed = (moveSpeed / 1.5f);
            swimSpeed = (swimSpeed / 1.5f);
            
        }
        else if (goldOnHold == 2)
        {
            moveSpeed = (moveSpeed / 2.5f);
            swimSpeed = (swimSpeed / 2.5f);
        }
        else if (goldOnHold == 10)
        {
            moveSpeed = (moveSpeed / 3.8f);
            swimSpeed = (swimSpeed / 3f);
        }
    }
    private void PlayerMove()
    {

        //if (Input.GetKey(KeyCode.W))
        //{
        //    transform.position += new Vector3(0, 0, moveSpeed * Time.deltaTime);
        //}
        //if (Input.GetKey(KeyCode.S))
        //{
        //    transform.position += new Vector3(0, 0, -moveSpeed * Time.deltaTime);
        //}
        //if (Input.GetKey(KeyCode.A))
        //{
        //    transform.position += new Vector3(-moveSpeed * Time.deltaTime, 0, 0);
        //}
        //if (Input.GetKey(KeyCode.D))
        //{
        //    transform.position += new Vector3(moveSpeed * Time.deltaTime, 0, 0);
        //}
        
        
        moveDirection = (transform.forward * Input.GetAxis("Vertical")+transform.right*Input.GetAxis("Horizontal"));
        moveDirection = moveDirection.normalized*moveSpeed;
        if(Input.GetKey(KeyCode.Q))
        {
            if (transform.position.y < 25)
            {

                // transform.position += new Vector3(0, swimSpeed * Time.deltaTime, 0);
                moveDirection.y = swimSpeed;
            }
        }
        if (Input.GetKey(KeyCode.E))
        {
            //transform.position += new Vector3(0, -swimSpeed * Time.deltaTime, 0);
            moveDirection.y = -swimSpeed;
        }

        controller.Move(moveDirection * Time.deltaTime);
    }

    public void ReturnSpeed()
    {
        moveSpeed = speedWithoutLoad;
        swimSpeed = 6f;
    }

    public void DecreaseSpeed()
    {
        moveSpeed /= 2;
        swimSpeed /= 2;
    }
}
