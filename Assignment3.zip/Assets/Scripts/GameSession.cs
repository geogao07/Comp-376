﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GameSession : MonoBehaviour
{
    [SerializeField] int playerLives = 2;
    [SerializeField] int score = 0;
    [SerializeField] int fatigue = 2000;
    [SerializeField] Text livesText;
    [SerializeField] Text ScoreText;
    [SerializeField] Text FatigueText;


    private void Awake()
    {
        int numGameSessions = FindObjectsOfType<GameSession>().Length;
        if (numGameSessions > 1)
        {
            Destroy(gameObject);

        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }

    }
    // Start is called before the first frame update
    void Start()
    {
        livesText.text = "HP: "+playerLives.ToString();
        ScoreText.text = "Score: "+score.ToString();
        FatigueText.text= "Fatigue: " + fatigue.ToString();
    }

    public void AddToScore(int pointsToAdd)
    {
        score += pointsToAdd;
        ScoreText.text = "Score: "+score.ToString();
        FindObjectOfType<PlayerController>().ReturnSpeed();
    }
    public void removeFatigue()
    {
        fatigue--;
        FatigueText.text = "Fatigue: "+fatigue.ToString();
        if (fatigue <= 0)
        {
            ProcessPlayerDeath();
        }
    }

    public void recoverFatigue()
    {
        if (fatigue < 2000)
            fatigue++;
        FatigueText.text = "Fatigue: " + fatigue.ToString();
    }
    public void ProcessPlayerDeath()
    {

       
        if (playerLives > 1)
        {
            TakeLife();

        }
        else
        {
            ResetGameSession();
        }
    }

    private void TakeLife()
    {
        playerLives--;
        
        
        livesText.text = "HP: "+playerLives.ToString();
        FindObjectOfType<PlayerController>().DecreaseSpeed();

    }

    private void ResetGameSession()
    {
        SceneManager.LoadScene(0);
        Destroy(gameObject);
    }
}
