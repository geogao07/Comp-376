﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeController : MonoBehaviour
{
    [SerializeField] float speed=10f;
    private Rigidbody rb;
    private GameObject player;
    private Vector3 currentPlayerPosition;
    Vector3 moveDirection;
    
    // Start is called before the first frame update
    void Start()
    {
       rb = GetComponent<Rigidbody>();
        player = GameObject.Find("Player");
      
        currentPlayerPosition = player.transform.position;
        
        moveDirection = (currentPlayerPosition - transform.position).normalized * speed;
        rb.velocity =new Vector3(moveDirection.x, moveDirection.y, moveDirection.z);

        Destroy(gameObject,4f);
    }

    //private void OnCollisionEnter(Collision collision)
    //{
    //    if (collision.collider.tag == "shark")
    //    { Destroy(gameObject); }
    //    if (collision.collider.tag == "Player")
    //    { Destroy(gameObject); }
    //}
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "shark")
        { Destroy(gameObject); }
        if (other.tag == "Player")
        { Destroy(gameObject); }
        if (other.tag == "Environment")
        { Destroy(gameObject); }
    }

}
