﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateShark : MonoBehaviour
{
    [SerializeField] float spawnTime;
    [SerializeField] float rageTime;
    public GameObject SharkPrefab;
    public GameObject RageShark;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        rageTime -= Time.deltaTime;
        checkSpawnTime();
        
    }

  

    private void checkSpawnTime()
    {
        spawnTime -= Time.deltaTime;
        if (spawnTime <= 0 && rageTime >= 0)
        {
            SpawnShark();
            spawnTime = 10f;
        }
        else if (spawnTime <= 0 &&rageTime < 0)
        {
            SpawnRageShark();
            spawnTime = 5f;
        }
    }

    private void SpawnRageShark()
    {
        Vector3 position = new Vector3(UnityEngine.Random.Range(-8, 19), UnityEngine.Random.Range(10, 21), UnityEngine.Random.Range(6, 30));
        Instantiate(RageShark, position, Quaternion.identity);
    }

    private void SpawnShark()
    {
        Vector3 position = new Vector3(UnityEngine.Random.Range(-8,19), UnityEngine.Random.Range(10, 21), UnityEngine.Random.Range(6, 30));
        Instantiate(SharkPrefab, position,Quaternion.identity);
    }
}
