﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public Transform target;
    public Vector3 offset;

    public bool useOffsetValue;

    public float rotateSpeed=5f;

    public Transform pivot;

    // Start is called before the first frame update
    void Start()
    {
        if (!useOffsetValue)
        {
            offset = target.position - transform.position;
        }
        pivot.transform.position = target.transform.position;
        pivot.transform.parent = target.transform;

        //hide cursor
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        //get x and rotate
        float horizontal = Input.GetAxis("Mouse X")*rotateSpeed;
        target.Rotate(0, horizontal, 0);
        //get x and rotate
        float vertical = Input.GetAxis("Mouse Y") * rotateSpeed;
        pivot.Rotate(-vertical, 0, 0);

        //move camera based on current rotation
        float disiredYAngle = target.eulerAngles.y;
        float disiredXAngle = pivot.eulerAngles.x;
        Quaternion rotation = Quaternion.Euler(disiredXAngle, disiredYAngle, 0);
       transform.position = target.position - (rotation*offset);
       
       // transform.position = target.position - offset;

        //if(transform.position.y<target.position.y)
        //{
        //    transform.position = new Vector3(transform.position.x, target.position.y, transform.position.z);
        //}
            transform.LookAt(target);
    }
}
