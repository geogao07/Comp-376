﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SharkController : MonoBehaviour
{
    [SerializeField] float moveSpeed;
    [SerializeField] float timer;
    [SerializeField] float distractTime;
    
    
    private GameObject player;
    private Vector3 currentPlayerPosition;
    private Vector3 currentPosition;
    Rigidbody myRigidBody;
    private Vector3 normalizeDirection;
   
   

    // Start is called before the first frame update
    void Start()
    {   
        myRigidBody = GetComponent<Rigidbody>();
        player = GameObject.Find("Player");
        currentPlayerPosition = player.transform.position;
        normalizeDirection = (currentPlayerPosition - transform.position).normalized;
        currentPosition = transform.position;
        var Direction = currentPlayerPosition - currentPosition;
      // Direction.z = 0;
       
        transform.rotation = Quaternion.LookRotation(new Vector3(currentPosition.x, 0,0));
        distractTime = 0;
        

    }

    // Update is called once per frame
    void Update()
    {
        if (distractTime <= 0)
        {
            move();
        }
        distractTime -= Time.deltaTime;
            timer -= Time.deltaTime;
        
        checkTime();
        
        
    }

   

    private void checkTime()
    {
        if (timer <= 0)
        {
            Destroy(gameObject);
        }
    }

    private void move()
    {
        transform.position += normalizeDirection * moveSpeed * Time.deltaTime;
    }

   // void OnCollisionEnter(Collision collision)
    //{
    //    if (collision.collider.tag == "Player")
    //    {
    //        Destroy(gameObject);
    //    }
      // if (collision.collider.tag == "Environment")
     //  {
     //      transform.position = currentPosition;
    //   }
    //    if (collision.collider.tag == "Net")
    //    {
    //        distractTime = 4f;
    //    }

   // }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Destroy(gameObject);
        }
        if (other.tag == "Environment")
        {
            transform.position = currentPosition;
        }
        if (other.tag == "Net")
        {
            distractTime = 4f;
        }
    }


}
