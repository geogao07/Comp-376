﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OctopusController : MonoBehaviour
{

    
    [SerializeField] float aliveTime=10f;
    [SerializeField] float shootTime=3f;

    private Rigidbody rb;

  
    public GameObject knife;
   
    // Start is called before the first frame update
    void Start()
    {
        shootTime = 0f;
       // rb =transform.GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        shootTime -= Time.deltaTime;
        aliveTime -= Time.deltaTime;
        if (shootTime <= 0f)
        {
            Instantiate(knife,transform.position,Quaternion.identity);
            shootTime = 3f;
        }
        if (aliveTime <= 0f)
        {
            Destroy(gameObject);
        }
        
    }
}
