﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nitro : MonoBehaviour
{
    BoxCollider2D myBodyCollider;

    void Start()
    {
        myBodyCollider = GetComponent<BoxCollider2D>();
    }
    void Update()
    {
        if (myBodyCollider.IsTouchingLayers(LayerMask.GetMask("Player")))
        {
            
            FindObjectOfType<player>().GetNitro();
            Destroy(gameObject);
        }
    }
}
