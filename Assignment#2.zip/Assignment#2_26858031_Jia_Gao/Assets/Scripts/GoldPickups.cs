﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldPickups : MonoBehaviour
{
    [SerializeField] int pointsForPickUp = 1;
    BoxCollider2D myBodyCollider;


     void Start()
    {
        myBodyCollider = GetComponent<BoxCollider2D>();
    }
    void Update()
    {
        if (myBodyCollider.IsTouchingLayers(LayerMask.GetMask("Player")))
            {
            FindObjectOfType<player>().CarryGold(pointsForPickUp);
            Destroy(gameObject);
        }
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    //FindObjectOfType<GameSession>().AddToScore(pointsForPickUp);
    //    FindObjectOfType<player>().CarryGold(pointsForPickUp);
    //    Destroy(gameObject);
    //}
}
