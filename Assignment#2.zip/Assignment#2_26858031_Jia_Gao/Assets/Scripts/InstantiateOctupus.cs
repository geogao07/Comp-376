﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiateOctupus : MonoBehaviour
{
    // Reference to the Prefab. Drag a Prefab into this field in the Inspector.
    public GameObject myPrefab;

    // This script will simply instantiate the Prefab when the game starts.
    void Start()
    {
        // Instantiate at position (0, 0, 0) and zero rotation.
        for (int i = 0; i < 3; i++)
        {
            Vector3 position = new Vector3(Random.Range(-8f, 8.0f),-1,0 );
            Instantiate(myPrefab, position, Quaternion.identity);
        }
    }
}
