﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class player : MonoBehaviour
{
    [SerializeField]
    float mMoveSpeed;

    [SerializeField]Vector2 deathKick=new Vector2(25,25);

    //state
    bool isAlive = true;
    int goldOnHold = 0;
    bool hasNitro = false;

    float speedWithoutLoad = 0;
    
    Rigidbody2D mRigidBody2D;
    BoxCollider2D myBodyCollider;
    Animator myAnimator;

    // Start is called before the first frame update
    void Start()
    {
        
        mRigidBody2D = GetComponent<Rigidbody2D>();
        myBodyCollider = GetComponent<BoxCollider2D>();
        myAnimator = GetComponent<Animator>();
        speedWithoutLoad = mMoveSpeed;


    }


    //die method
    private void Die()
    {
        if (myBodyCollider.IsTouchingLayers(LayerMask.GetMask("Enemy")))
        {
         //   Physics2D.IgnoreLayerCollision(8,9,true);
           isAlive = false;
            myAnimator.SetTrigger("Dying");
           GetComponent<Rigidbody2D>().velocity = deathKick;
          FindObjectOfType<GameSession>().ProcessPlayerDeath();
            
           Destroy(GameObject.Find("Cylinder1"));
        //    Physics2D.IgnoreLayerCollision(8, 9, false);

        }
    }

    // Update is called once per frame
    void Update()
    {
        if (hasNitro)
        {
            mMoveSpeed = mMoveSpeed * 2f;
            hasNitro = false;
        }
        if (!isAlive)
        {
            return;
        }
        if (Input.GetButton("Left"))
        {
            
            transform.Translate(-Vector2.right * mMoveSpeed * Time.deltaTime);
            if (transform.position.x <- 8)
            {
                transform.position = new Vector2(8, transform.position.y);
            }
            
        }
        if (Input.GetButton("Right"))
        {
            transform.Translate(Vector2.right * mMoveSpeed * Time.deltaTime);
            if (transform.position.x >8)
            {
                transform.position = new Vector2(-8, transform.position.y);
            }
        }
        if (Input.GetButton("Up"))
        {
            transform.Translate(Vector2.up * mMoveSpeed * Time.deltaTime);

        }
        if (Input.GetButton("Down"))
        {
            transform.Translate(-Vector2.up * mMoveSpeed * Time.deltaTime);

        }
        
        
        Die();
        GetScore();
        
    }

    public void GetScore()
    {
        if (myBodyCollider.IsTouchingLayers(LayerMask.GetMask("Ship")))
        {
            FindObjectOfType<GameSession>().AddToScore(goldOnHold);
            goldOnHold = 0;

        }
    }

    public void CarryGold(int gold)
    {
        goldOnHold = gold;
        
        if (goldOnHold == 1)
        {
            mMoveSpeed = (mMoveSpeed / 1.5f);
        }
        else if (goldOnHold == 2)
        {
            mMoveSpeed = (mMoveSpeed / 2.5f);
        }
        else if (goldOnHold == 10)
        {
            mMoveSpeed = (mMoveSpeed / 3.8f);
        }
    }
    public void ReturnSpeed()
    {
        mMoveSpeed = speedWithoutLoad;
    }
    public void GetNitro()
    {
        hasNitro = true;

    }

  public  void DecreaseSpeed() {
        mMoveSpeed /= 2;
    }
}
