﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OctopusMove : MonoBehaviour
{
    
        [SerializeField] float moveSpeed = 1f;

        Rigidbody2D myRigidBody;

        // Start is called before the first frame update
        void Start()
        {
            myRigidBody = GetComponent<Rigidbody2D>();
        }

        // Update is called once per frame
        void Update()
        {

        if (myRigidBody.position.y >= -1.2)
        {
            myRigidBody.velocity = new Vector2(0f, -moveSpeed);
        }
        else if (myRigidBody.position.y <=-4.5)
        {
            myRigidBody.velocity = new Vector2(0f, moveSpeed);
        }
        
    }
    
}
