In order to run this game, simply substract the file and open assets->Levels->MainMenu.unity it will install the required files.

This game is written using Unity 2018.3.14f so generally all Unity 3.* should able to do the job.
